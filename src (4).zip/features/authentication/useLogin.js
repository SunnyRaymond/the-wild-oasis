import { useMutation, useQueryClient } from "@tanstack/react-query";
import { login as loginApi } from "../../services/apiAuth";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

export function useLogin() {
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { mutate: login, isLoading } = useMutation({
    mutationFn: ({ email, password }) => {
      loginApi({ email, password });
    },
    onSuccess: (user) => {
      // Redirect to the dashboard
      queryClient.setQueryData(["user"], user);
      navigate("/dashboard");
    },
    onError: (error) => {
      toast.error(" Invalid email or password");
      console.error(error);
    },
  });

  return { login, isLoading };
}
